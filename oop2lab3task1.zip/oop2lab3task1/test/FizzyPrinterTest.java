import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FizzyPrinterTest {

    @Test
    public void testFizz() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Fizz", fizzyPrinter.printFizzy(9, false), "Expected 'Fizz' for 9");
    }

    @Test
    public void testBuzz() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Buzz", fizzyPrinter.printFizzy(10, false), "Expected 'Buzz' for 10");
    }

    @Test
    public void testBang() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Bang", fizzyPrinter.printFizzy(14, false), "Expected 'Bang' for 14");
    }

    @Test
    public void testFizzBuzz() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Fizzbuzz", fizzyPrinter.printFizzy(15, false), "Expected 'Fizzbuzz' for 15");
    }

    @Test
    public void testFizzBuzzBang() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Fizzbuzzbang", fizzyPrinter.printFizzy(105, false), "Expected 'Fizzbuzzbang' for 105");
    }

    @Test
    public void testBoom() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("Boom", fizzyPrinter.printFizzy(8, false), "Expected 'Boom' for 8");
    }

    @Test
    public void testUpperCase() {
        FizzyPrinter fizzyPrinter = new FizzyPrinter();
        assertEquals("FIZZBUZZ", fizzyPrinter.printFizzy(15, true), "Expected 'FIZZBUZZ' for 15 in upper case");
    }
}
